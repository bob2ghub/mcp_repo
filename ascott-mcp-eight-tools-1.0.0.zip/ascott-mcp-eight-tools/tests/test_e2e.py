"""Run against an actual Mule server and the local simulator: python tests/test_e2e.py."""
import concurrent.futures
from datetime import date,timedelta
import json
from pathlib import Path
import sys
import unittest
from urllib.request import urlopen
import uuid
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'client'))
from mcp_client import MCPClient,MCPError

class EndToEnd(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.client=MCPClient()
        cls.info=cls.client.initialize()
        with urlopen('http://127.0.0.1:8081/health') as r:
            assert json.load(r)['mode']=='SIMULATOR','Tests require the simulator'
        start=date.today()+timedelta(days=31+uuid.uuid4().int%10000)
        cls.stay={'checkIn':start.isoformat(),'checkOut':(start+timedelta(days=2)).isoformat(),'adults':2}

    @classmethod
    def tearDownClass(cls):
        cls.client.close()

    def call_ok(self,name,args):
        result=self.client.call(name,args)
        self.assertFalse(result.get('isError'),result)
        content=self.client.content(result)
        self.assertTrue(content['success'])
        self.assertTrue(content['correlationId'])
        return content['data']

    def call_error(self,name,args,category=None):
        result=self.client.call(name,args)
        self.assertTrue(result.get('isError'),result)
        content=self.client.content(result)
        if category:
            self.assertEqual(content['error']['category'],category)
        return content

    def booking_args(self):
        return {'propertyId':'SG-001',**self.stay,'roomId':'STUDIO','rateId':'SG-001-STUDIO-FLEX','expectedTotal':480,'currency':'SGD','guest':{'name':'Demo Guest','email':'demo@example.com'},'confirmed':True,'idempotencyKey':'test-'+uuid.uuid4().hex}

    def test_01_catalog(self):
        expected={'findPropertiesByLocation','getPropertyDetails','getServiceOfferings','getRoomAndRateDetails','getPromotionsAndDeals','compareProperties','compareRoomsAndRates','createBooking'}
        tools=self.client.list_tools()
        self.assertEqual({t['name'] for t in tools},expected)
        for tool in tools:
            self.assertEqual(tool['inputSchema']['type'],'object')
            self.assertFalse(tool['inputSchema']['additionalProperties'])

    def test_02_all_reads(self):
        self.assertEqual(len(self.call_ok('findPropertiesByLocation',{'location':'Singapore'})['properties']),3)
        self.assertEqual(self.call_ok('getPropertyDetails',{'propertyId':'SG-001'})['propertyId'],'SG-001')
        self.assertTrue(self.call_ok('getServiceOfferings',{'propertyId':'SG-001'})['services'])
        self.assertEqual(self.call_ok('getRoomAndRateDetails',{'propertyId':'SG-001',**self.stay})['rooms'][0]['total'],480)
        self.assertTrue(self.call_ok('getPromotionsAndDeals',{'propertyId':'SG-001'})['promotions'])
        for tool in ('compareProperties','compareRoomsAndRates'):
            args={'propertyIds':['SG-001','SG-002']}
            if tool=='compareRoomsAndRates':
                args.update(self.stay)
            result=self.call_ok(tool,args)
            self.assertEqual([p['propertyId'] for p in result['properties']],['SG-001','SG-002'])

    def test_03_empty_and_missing(self):
        self.assertEqual(self.call_ok('findPropertiesByLocation',{'location':'Nowhere'})['properties'],[])
        self.call_error('getPropertyDetails',{'propertyId':'MISSING'},'FUNCTIONAL')

    def test_04_schema_validation(self):
        for tool,args in [('getPropertyDetails',{}),('getPropertyDetails',{'propertyId':'../secrets'}),('getPropertyDetails',{'propertyId':'SG-001','extra':True}),('compareProperties',{'propertyIds':['SG-001','SG-001']}),('getRoomAndRateDetails',{'propertyId':'SG-001',**self.stay,'adults':0})]:
            with self.subTest(tool=tool,args=args):
                try:
                    result=self.client.call(tool,args)
                    self.assertTrue(result.get('isError'),result)
                except MCPError:
                    pass # Connector can reject invalid inputs before entering the Mule flow.

    def test_05_dates(self):
        for changes in ({'checkOut':self.stay['checkIn']},{'checkIn':'2020-01-01'},{'checkIn':'2027-02-30'}):
            try:
                self.call_error('getRoomAndRateDetails',{'propertyId':'SG-001',**self.stay,**changes})
            except MCPError:
                pass

    def test_06_booking_confirmation_price_idempotency(self):
        args=self.booking_args()
        self.call_error('createBooking',{**args,'confirmed':False},'FUNCTIONAL')
        self.call_error('createBooking',{**args,'expectedTotal':1},'FUNCTIONAL')
        first=self.call_ok('createBooking',args)
        second=self.call_ok('createBooking',args)
        self.assertEqual(first,second)
        self.assertEqual(first['status'],'CONFIRMED_SIMULATION')
        self.call_error('createBooking',{**args,'adults':1},'FUNCTIONAL')

    def test_07_technical_failures(self):
        for pid in ('TECH-503','TECH-TIMEOUT'):
            result=self.call_error('getPropertyDetails',{'propertyId':pid},'TECHNICAL')
            self.assertTrue(result['error']['retryable'])
            self.assertNotIn('stack',json.dumps(result).lower())

    def test_08_comparison_failure(self):
        result=self.call_error('compareProperties',{'propertyIds':['SG-001','TECH-503']},'TECHNICAL')
        self.assertEqual(result['error']['code'],'COMPARISON_FAILED')

    def test_09_concurrent_booking_retries(self):
        args=self.booking_args()
        def invoke(_):
            client=MCPClient()
            try:
                client.initialize()
                result=client.call('createBooking',args)
                self.assertFalse(result.get('isError'),result)
                return client.content(result)['data']['bookingId']
            finally:
                client.close()
        with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
            results=list(pool.map(invoke,range(4)))
        self.assertEqual(len(set(results)),1)

    def test_10_unknown_tool(self):
        with self.assertRaises(MCPError):
            self.client.call('notATool',{})

if __name__=='__main__':
    unittest.main(verbosity=2)

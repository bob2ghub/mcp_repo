# Ascott MuleSoft MCP server — local ODX simulator

Eight native MuleSoft MCP tools implement the business-tool column of the supplied slide. All property data, prices and reservations are fictional. A successful booking returns `CONFIRMED_SIMULATION`; no ODX account, payment provider or OpenAI API key is used.

## Run locally

Requirements: Python 3.10+, Anypoint Studio with Java 17 and Mule 4.12 EE. This machine uses `C:\AnypointStudio28\AnypointStudio`. The application uses MCP connector 1.7.0 and HTTP connector 1.12.1. Maven dependencies must be available locally or downloadable from the configured repositories. Runtime licensing remains supplied by your Studio installation.

Run commands from this project directory:

```powershell
python scripts\local.py simulator
```

The project is imported in Studio as `ascott-mcp-eight-tools`. Select **Run > Run Configurations > Mule Applications > ascott-mcp-eight-tools**. Under **JRE**, use **Alternate JRE: Studio-JDK-17**. Under **General**, use Mule Server 4.12.3 EE. Click **Run** and wait for `DEPLOYED`.

For a fresh Studio installation, import with **File > Import > Anypoint Studio > Anypoint Studio project from File System**, selecting this directory. Add Studio's bundled JDK directory under **Installed JREs**, if needed. The JRE home is the JDK root, not its `bin` directory. Use a Studio installation path without spaces on Windows, because the Mule batch launcher can fail on paths containing spaces.

Alternatively, start the same native Mule application without the Studio UI:

```powershell
python scripts\local.py build
python scripts\local.py start
python scripts\local.py status
```

Pass `--studio "C:\your\AnypointStudio"` to `build` or `start` for another installation. `start` uses the packaged JAR in `target`, launches the simulator, and starts Mule in a project-local `.runtime/mule` base. Startup can take 1–2 minutes. Do not run the Studio and portable instances on port 8081 simultaneously. Stop a Studio launch using its Console's red stop button; use `scripts\Stop-Local.ps1` for instances created by the portable launcher.

| Endpoint | Purpose |
|---|---|
| `http://127.0.0.1:8081/mcp` | MCP Streamable HTTP (JSON-RPC, managed by the native connector) |
| `http://127.0.0.1:8081/health` | Mule service liveness and simulator mode |
| `http://127.0.0.1:8091/health` | Dummy ODX liveness |
| `http://127.0.0.1:8091/odx/v1` | Dummy downstream REST base |

Mule health is a liveness check, not a downstream readiness check. `local.py status` checks both processes. The services bind to loopback by default.

## Sample client and tests

For the interactive browser demonstration, run:

```powershell
python client\live_demo.py
```

Open `http://127.0.0.1:8092`. **Run all 8 tools** executes the complete live sequence and creates one simulated booking from the returned quote. Select a completed row to inspect its request, decoded response, raw MCP result, duration and correlation ID. **Test error handling** demonstrates a missing property, downstream 503 and a five-second timeout. This viewer calls the actual Mule endpoint through the included Python MCP client; it does not supply canned MCP responses. Keep Mule and the ODX simulator running. Stop the foreground demo server with Ctrl+C.

```powershell
python client\mcp_client.py --list
python client\mcp_client.py --demo --output logs\demo-results.json
python tests\test_e2e.py
```

The demo initializes a real MCP session, discovers tools, exercises all seven reads/comparisons, obtains a quote and creates one simulated booking. It refuses to book unless the server reports `SIMULATOR` mode. Each demo generates future dates and a fresh booking key. The test suite covers schema validation, missing data, invalid dates, confirmation, price conflicts, durable booking retries, concurrent same-key calls, unavailable downstreams and timeouts.

For individual calls, use JSON argument files to avoid PowerShell quoting differences:

```powershell
python client\mcp_client.py --tool findPropertiesByLocation --args-file client\examples\findPropertiesByLocation.json
```

Examples for all eight tools are in `client/examples`. Update stay dates if they have passed. For booking, obtain the latest rate first, review the property, dates, occupancy and total, and set `confirmed=true` only after approval. Reuse the same `idempotencyKey` and identical body for a retry. A new booking needs a new key. The demo uses only `demo@example.com`; the simulator sends no email.

## Business tools

| Business tool | MCP ID | Processing |
|---|---|---|
| Find properties in location | `findPropertiesByLocation` | GET properties by city/country |
| Get Property Details | `getPropertyDetails` | GET property details |
| Get Services Offerings / Service Details | `getServiceOfferings` | GET services/content |
| Get Room and Rate Details | `getRoomAndRateDetails` | GET rates for stay and occupancy |
| Promotions and Deals at Properties | `getPromotionsAndDeals` | GET promotions |
| Compare Properties | `compareProperties` | Parallel property reads |
| Compare Rooms and Rates | `compareRoomsAndRates` | Parallel rate reads |
| Create Booking | `createBooking` | POST confirmed, quoted booking with idempotency key |

The simulator supplies SG-001, SG-002 and SG-003 in Singapore, studio/family rooms, SGD prices, up to 6 adults and stays of 1–30 nights. Comparisons accept 2–5 unique property IDs, preserve input order and use an all-or-nothing result. Promotions are informational and do not change FLEX prices. `inventoryCapacity` is the simulated stock limit, not a live remaining-room count; booking performs the atomic availability check.

## Implementation and extension points

`src/main/mule/global-config.xml` defines MCP/HTTP configuration and health. `mcp-tools.xml` contains the eight native listeners. Every listener references validation, a business flow, logging and the same generic error handler. `business-flows.xml` contains downstream requests and parallel orchestration. `error-handlers.xml` and `observability.xml` provide reusable exception and logging flows.

```mermaid
flowchart LR
  C[ChatGPT plugin or sample MCP client] --> M[Native Mule MCP listener]
  M --> V[Schema and business validation]
  V --> B[Business subflows]
  B --> O[Dummy ODX REST APIs]
  O --> D[(SQLite booking idempotency and inventory)]
  B --> R[MCP result]
  V --> E[Generic functional or technical handler]
  B --> E
  E --> R
```

Input schemas live in `src/main/resources/schemas`. `scripts/generate_contracts.py` generates these, listener definitions and `tool-catalog.json`. The catalog includes proposed MCP annotations for client/gateway use; native MCP connector 1.7.0 does not expose these annotations in this implementation's `tools/list`. Tool descriptions explicitly identify reads and booking writes. Successful business results are JSON inside MCP text content; no structured output schema or widget UI is advertised.

The dummy ODX contract is documented in `docs/odx-contract.md`; it is an assumed local contract, not an official ODX specification. To integrate real ODX, replace the request/response mappings and configure `odx.*` properties after obtaining the real contract. Authentication, currency/pricing and booking reconciliation must match that contract. Simply changing the host is not sufficient. The SQLite booking store is simulator-only.

See `docs/error-handling.md` for shared error flows and logging, and `docs/chatgpt-connection.md` for ChatGPT setup and its remaining connection requirements.

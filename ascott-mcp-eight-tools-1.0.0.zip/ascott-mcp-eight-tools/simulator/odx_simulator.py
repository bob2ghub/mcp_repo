"""Local ODX contract simulator. All hotels, prices and bookings are fictional.

Python standard library only. SQLite transactions make booking retries durable and
concurrent inventory checks atomic. Never use guest/payment production data here.
"""
import argparse
import hashlib
import json
import logging
from logging.handlers import RotatingFileHandler
import os
from pathlib import Path
import re
import sqlite3
import time
from datetime import date
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlsplit
import uuid

ROOT = Path(__file__).resolve().parents[1]
PROPERTIES = [
    {'propertyId':'SG-001','name':'Ascott Orchard Demo','city':'Singapore','country':'Singapore','stars':5,'amenities':['Wi-Fi','Pool','Gym','Kitchen'],'nightly':240},
    {'propertyId':'SG-002','name':'Citadines Marina Demo','city':'Singapore','country':'Singapore','stars':4,'amenities':['Wi-Fi','Gym','Laundry'],'nightly':180},
    {'propertyId':'SG-003','name':'Somerset Riverside Demo','city':'Singapore','country':'Singapore','stars':4,'amenities':['Wi-Fi','Pool','Kitchen'],'nightly':210},
]
LOG = logging.getLogger('odx.simulator')

class BusinessError(Exception):
    def __init__(self, status, code, message):
        self.status, self.code, self.message = status, code, message

def fail(status, code, message):
    raise BusinessError(status, code, message)

def property_by_id(pid):
    return next((p for p in PROPERTIES if p['propertyId'] == pid), None) or fail(404,'NOT_FOUND','Property not found')

def stay(args):
    try:
        start, end = date.fromisoformat(args['checkIn']), date.fromisoformat(args['checkOut'])
        adults = args['adults']
        if isinstance(adults, str) and adults.isdigit():
            adults = int(adults)
        if type(adults) is not int or not 1 <= adults <= 6:
            raise ValueError()
        nights = (end-start).days
        if start < date.today() or not 1 <= nights <= 30:
            raise ValueError()
        return nights, adults
    except (ValueError, KeyError, TypeError):
        fail(400,'INVALID_STAY','Valid future dates, 1-30 nights and 1-6 adults are required')

def quote(prop, args):
    nights, adults = stay(args)
    rooms = []
    for kind, capacity, nightly in [('STUDIO',2,prop['nightly']),('FAMILY',6,prop['nightly']+100)]:
        if adults <= capacity:
            rate = f"{prop['propertyId']}-{kind}-FLEX"
            rooms.append({'roomId':kind,'rateId':rate,'name':kind.title(),'maxAdults':capacity,'nightlyRate':nightly,'nights':nights,'total':nightly*nights,'currency':'SGD','taxesIncluded':True,'cancellationPolicy':'Demo: free cancellation before check-in','inventoryCapacity':3})
    return {'propertyId':prop['propertyId'],'checkIn':args['checkIn'],'checkOut':args['checkOut'],'adults':adults,'rooms':rooms,'simulated':True}

def init_db(db):
    with sqlite3.connect(db) as conn:
        conn.execute('PRAGMA journal_mode=WAL')
        conn.execute('CREATE TABLE IF NOT EXISTS bookings (key TEXT PRIMARY KEY, fingerprint TEXT NOT NULL, response TEXT NOT NULL, property_id TEXT NOT NULL, room_id TEXT NOT NULL, check_in TEXT NOT NULL, check_out TEXT NOT NULL)')

def create_booking(db, args, key):
    if args.get('confirmed') is not True:
        fail(400,'CONFIRMATION_REQUIRED','Explicit confirmation required')
    if not isinstance(key,str) or not re.fullmatch(r'[A-Za-z0-9_-]{8,64}',key) or key != args.get('idempotencyKey'):
        fail(400,'INVALID_IDEMPOTENCY_KEY','A matching stable idempotency key is required')
    guest = args.get('guest',{})
    if not isinstance(guest,dict) or not isinstance(guest.get('name'),str) or not guest['name'].strip() or not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+',str(guest.get('email',''))):
        fail(400,'INVALID_GUEST','Guest name and email are required')
    digest = hashlib.sha256(json.dumps(args,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    with sqlite3.connect(db, timeout=10) as conn:
        conn.execute('BEGIN IMMEDIATE')
        existing = conn.execute('SELECT fingerprint,response FROM bookings WHERE key=?',(key,)).fetchone()
        if existing:
            if digest != existing[0]:
                fail(409,'IDEMPOTENCY_CONFLICT','Key already used with different booking details')
            return json.loads(existing[1])
        prop = property_by_id(args.get('propertyId'))
        rates = quote(prop,args)
        room = next((r for r in rates['rooms'] if r['roomId']==args.get('roomId') and r['rateId']==args.get('rateId')),None)
        if room is None:
            fail(409,'RATE_NOT_FOUND','Room or rate is no longer available for this occupancy')
        if type(args.get('expectedTotal')) not in (int,float) or args['expectedTotal'] != room['total'] or args.get('currency') != room['currency']:
            fail(409,'PRICE_CHANGED','The expected total or currency differs from the current quote')
        # Check capacity on EVERY night, rather than counting non-overlapping reservations together.
        occupied = conn.execute('SELECT check_in,check_out FROM bookings WHERE property_id=? AND room_id=? AND check_in<? AND check_out>?',(prop['propertyId'],room['roomId'],args['checkOut'],args['checkIn'])).fetchall()
        start, end = date.fromisoformat(args['checkIn']), date.fromisoformat(args['checkOut'])
        if any(sum(date.fromisoformat(a).toordinal() <= day < date.fromisoformat(b).toordinal() for a,b in occupied) >= 3 for day in range(start.toordinal(),end.toordinal())):
            fail(409,'SOLD_OUT','No inventory remains for one or more nights')
        response = {'bookingId':'DEMO-'+uuid.uuid4().hex[:12].upper(),'status':'CONFIRMED_SIMULATION','propertyId':prop['propertyId'],'roomId':room['roomId'],'rateId':room['rateId'],'checkIn':args['checkIn'],'checkOut':args['checkOut'],'adults':args['adults'],'total':room['total'],'currency':room['currency'],'simulated':True}
        # Store only a request fingerprint and a PII-free response. Do not persist the guest.
        conn.execute('INSERT INTO bookings VALUES (?,?,?,?,?,?,?)',(key,digest,json.dumps(response),prop['propertyId'],room['roomId'],args['checkIn'],args['checkOut']))
        return response

class Handler(BaseHTTPRequestHandler):
    server_version = 'ODXSimulator/1.0'
    def log_message(self,*args):
        pass

    def reply(self,status,body):
        data = json.dumps(body).encode()
        self.send_response(status)
        self.send_header('Content-Type','application/json')
        self.send_header('Content-Length',str(len(data)))
        self.send_header('Cache-Control','no-store')
        self.end_headers()
        try:
            self.wfile.write(data)
        except (BrokenPipeError,ConnectionResetError,ConnectionAbortedError):
            pass

    def do_GET(self):
        self.handle_request()

    def do_POST(self):
        self.handle_request()

    def handle_request(self):
        began=time.monotonic()
        correlation=self.headers.get('X-Correlation-ID','')
        if not re.fullmatch(r'[A-Za-z0-9_-]{1,80}',correlation):
            correlation=uuid.uuid4().hex
        status=500
        try:
            url=urlsplit(self.path)
            if url.path == '/health' and self.command=='GET':
                status=200
                self.reply(status,{'status':'UP','mode':'SIMULATOR'})
                return
            if self.headers.get('Authorization') != 'Bearer '+self.server.token:
                fail(401,'UNAUTHORIZED','Invalid simulator token')
            segments=url.path.strip('/').split('/')
            if segments[:2] != ['odx','v1']:
                fail(404,'NOT_FOUND','Unknown endpoint')
            parts=segments[2:]
            query={k:v[0] for k,v in parse_qs(url.query).items()}
            if parts==['bookings'] and self.command=='POST':
                length=int(self.headers.get('Content-Length','0'))
                if length<=0 or length>16384:
                    fail(400,'INVALID_BODY','JSON body required; maximum 16 KiB')
                args=json.loads(self.rfile.read(length))
                if not isinstance(args,dict):
                    fail(400,'INVALID_BODY','JSON object required')
                body=create_booking(self.server.db,args,self.headers.get('Idempotency-Key'))
                status=201
            elif parts==['properties'] and self.command=='GET':
                location=query.get('location','').strip().casefold()
                limit=int(query.get('limit','20'))
                if not location or not 1<=limit<=50:
                    fail(400,'INVALID_SEARCH','Location and valid limit required')
                matches=[p for p in PROPERTIES if location in (p['city']+' '+p['country']).casefold()]
                body={'properties':matches[:limit],'total':len(matches),'simulated':True}
                status=200
            elif len(parts) in (2,3) and parts[0]=='properties' and self.command=='GET':
                # Reserved simulator-only failure IDs used by end-to-end tests.
                if parts[1]=='TECH-503':
                    fail(503,'UNAVAILABLE','Simulated downstream outage')
                if parts[1]=='TECH-TIMEOUT':
                    time.sleep(6)
                    fail(504,'TIMEOUT','Simulated downstream timeout')
                prop=property_by_id(parts[1])
                action=parts[2] if len(parts)==3 else 'details'
                if action=='details':
                    body={**prop,'description':'Fictional serviced residence for integration testing.','checkInTime':'15:00','checkOutTime':'11:00','simulated':True}
                elif action=='services':
                    body={'propertyId':prop['propertyId'],'services':[{'name':a,'included':True} for a in prop['amenities']],'simulated':True}
                elif action=='rates':
                    body=quote(prop,query)
                elif action=='promotions':
                    body={'propertyId':prop['propertyId'],'promotions':[{'promotionId':'DEMO-LONG-STAY','name':'Long stay information','description':'Demo offer: request a long-stay quote from the property. Not applied to FLEX rates.','automaticallyApplied':False}],'simulated':True}
                else:
                    fail(404,'NOT_FOUND','Unknown endpoint')
                status=200
            else:
                fail(404,'NOT_FOUND','Unknown endpoint or method')
            self.reply(status,body)
        except BusinessError as exc:
            status=exc.status
            self.reply(status,{'error':{'code':exc.code,'message':exc.message},'simulated':True})
        except (ValueError,TypeError,KeyError):
            status=400
            self.reply(status,{'error':{'code':'INVALID_REQUEST','message':'Malformed request'}})
        except Exception:
            self.reply(500,{'error':{'code':'INTERNAL_ERROR','message':'Simulator failed'}})
        finally:
            LOG.info(json.dumps({'event':'odx.request','correlationId':correlation,'method':self.command,'status':status,'durationMs':round((time.monotonic()-began)*1000)}))

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--port',type=int,default=8091)
    parser.add_argument('--db',type=Path,default=ROOT/'.runtime/bookings.db')
    args=parser.parse_args()
    args.db.parent.mkdir(parents=True,exist_ok=True)
    (ROOT/'logs').mkdir(exist_ok=True)
    LOG.setLevel(logging.INFO)
    LOG.addHandler(RotatingFileHandler(ROOT/'logs/odx-audit.jsonl',maxBytes=5_000_000,backupCount=3))
    init_db(args.db)
    server=ThreadingHTTPServer(('127.0.0.1',args.port),Handler)
    server.db=args.db
    server.token=os.environ.get('ODX_SIMULATOR_TOKEN','local-simulator')
    print(f'ODX SIMULATOR listening at http://127.0.0.1:{args.port}; fictional data only',flush=True)
    server.serve_forever()

if __name__=='__main__':
    main()

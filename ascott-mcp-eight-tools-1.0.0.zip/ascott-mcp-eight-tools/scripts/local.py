"""Portable local launcher using an existing Studio installation. No runtime download."""
import argparse
import json
import os
from pathlib import Path
import shutil
import socket
import subprocess
import sys
import time
from urllib.request import urlopen
import zipfile

ROOT=Path(__file__).resolve().parents[1]
DEFAULT_STUDIO=Path(r'C:\AnypointStudio28\AnypointStudio')

def paths(studio):
    jdks=sorted((studio/'plugins').glob('org.mule.tooling.jdk.win32.x86_64_*/bin/java.exe'))
    runtimes=sorted((studio/'plugins').glob('org.mule.tooling.server.4.12.ee_*/mule'))
    if not jdks or not runtimes:
        raise SystemExit('Java 17 and Mule 4.12 runtime were not found. Pass --studio with your Studio installation path.')
    return jdks[-1],runtimes[-1]

def build(studio):
    java,_=paths(studio)
    embedded=next((studio/'plugins').glob('org.mule.tooling.maven.embedded_*.jar'))
    maven=ROOT/'.tools/maven'
    if not (maven/'lib/maven-core.jar').exists():
        with zipfile.ZipFile(embedded) as z:
            for name in z.namelist():
                if name.startswith('lib/'):
                    z.extract(name,maven)
    repo=Path(os.environ.get('USERPROFILE',str(Path.home())))/'.m2/repository'
    command=[str(java),f'-Dmaven.repo.local={repo}',f'-Dmaven.multiModuleProjectDirectory={ROOT}','-cp',str(maven/'lib/*'),'org.apache.maven.cli.MavenCli','-B','package']
    return subprocess.call(command,cwd=ROOT)

def healthy(port):
    try:
        with urlopen(f'http://127.0.0.1:{port}/health',timeout=2) as r:
            return json.load(r)
    except Exception:
        return None

def port_free(port):
    with socket.socket() as sock:
        return sock.connect_ex(('127.0.0.1',port))!=0

def background(command,log):
    flags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0
    with open(ROOT/'logs'/log,'ab') as out:
        return subprocess.Popen(command,cwd=ROOT,stdout=out,stderr=out,stdin=subprocess.DEVNULL,creationflags=flags).pid

def start_simulator():
    if healthy(8091):
        print('Simulator already responds on port 8091')
        return
    if not port_free(8091):
        raise SystemExit('Port 8091 is in use by another service')
    pid=background([sys.executable,str(ROOT/'simulator/odx_simulator.py')],'simulator-console.log')
    (ROOT/'.runtime/simulator.pid').write_text(str(pid))
    print(f'Simulator started, PID {pid}')

def start(studio):
    start_simulator()
    if healthy(8081):
        print('Mule already responds on port 8081; no second instance started')
        return
    if not port_free(8081):
        raise SystemExit('Port 8081 is occupied. Stop the other service or use Studio with a different http.port.')
    artifact=ROOT/'target/ascott-mcp-eight-tools-1.0.0-mule-application.jar'
    if not artifact.exists():
        raise SystemExit('Build the application first: python scripts/local.py build')
    java,runtime=paths(studio)
    base=ROOT/'.runtime/mule'
    for directory in ['apps','domains/default','logs','conf','.mule']:
        (base/directory).mkdir(parents=True,exist_ok=True)
    for service in (runtime/'services').iterdir():
        if service.is_dir() and not (base/'services'/service.name).exists():
            shutil.copytree(service,base/'services'/service.name)
    for conf in (runtime/'conf').glob('*'):
        if conf.is_file() and not (base/'conf'/conf.name).exists():
            shutil.copy2(conf,base/'conf'/conf.name)
    shutil.copy2(artifact,base/'apps'/artifact.name)
    command=[str(java),'-Xms256m','-Xmx1024m',f'-Dmule.home={runtime}',f'-Dmule.base={base}',f'-Dmule.workingDirectory={base/".mule"}',f'-Dmule.logs.dir={base/"logs"}','-Dfile.encoding=UTF-8','-Djava.net.preferIPv4Stack=true','-Dmule.deployment.forceParseConfigXmls=true','--module-path',str(runtime/'lib/boot'),'--add-modules','ALL-MODULE-PATH']
    for module,package in [('java.base','java.lang'),('java.base','java.lang.reflect'),('java.base','java.lang.invoke'),('java.base','jdk.internal.ref'),('java.base','java.nio'),('java.base','sun.nio.ch'),('java.sql','java.sql'),('java.naming','javax.naming'),('java.management','sun.management'),('jdk.management','com.sun.management.internal')]:
        command.append(f'--add-opens={module}/{package}=org.mule.runtime.jpms.utils')
    pos=command.index('--add-modules')
    command[pos+1]='java.se,org.mule.runtime.boot.log4j,org.mule.runtime.logging,org.mule.runtime.jpms.utils,com.fasterxml.jackson.core,org.apache.commons.codec'
    command+=['-Dmule.bootstrap.container.wrapper.class=org.mule.runtime.module.boot.internal.MuleContainerBasicWrapper','-m','com.mulesoft.mule.boot/com.mulesoft.mule.runtime.MuleContainerBootstrap']
    pid=background(command,'mule-console.log')
    (ROOT/'.runtime/mule.pid').write_text(str(pid))
    print(f'Mule starting, PID {pid}. Follow logs/mule-console.log; startup can take 1-2 minutes.')

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command',choices=['build','simulator','start','status'])
    parser.add_argument('--studio',type=Path,default=DEFAULT_STUDIO)
    args=parser.parse_args()
    (ROOT/'logs').mkdir(exist_ok=True)
    (ROOT/'.runtime').mkdir(exist_ok=True)
    if args.command=='build':
        sys.exit(build(args.studio))
    elif args.command=='simulator':
        start_simulator()
    elif args.command=='start':
        start(args.studio)
    else:
        print(json.dumps({'mule':healthy(8081),'odx':healthy(8091)},indent=2))

if __name__=='__main__':
    main()

"""Regenerate tool schemas and native Mule listener flows from the approved catalog."""
import json
from pathlib import Path
from xml.sax.saxutils import escape

ROOT = Path(__file__).resolve().parents[1]
S = {'type': 'string', 'minLength': 1, 'maxLength': 100}
ID = dict(S, pattern='^[A-Za-z0-9_-]+$')
DATE = {'type': 'string', 'format': 'date', 'pattern': '^\\d{4}-\\d{2}-\\d{2}$'}
STAY = {'checkIn': DATE, 'checkOut': DATE, 'adults': {'type': 'integer', 'minimum': 1, 'maximum': 6}}
IDS = {'type': 'array', 'items': ID, 'minItems': 2, 'maxItems': 5, 'uniqueItems': True}
CATALOG = [
 ('findPropertiesByLocation', 'Find properties in location', {'location': dict(S, description='City or country, e.g. Singapore'), 'limit': {'type':'integer','minimum':1,'maximum':50}}, ['location'], 'search-properties'),
 ('getPropertyDetails', 'Get Property Details', {'propertyId': ID}, ['propertyId'], 'read-property'),
 ('getServiceOfferings', 'Get Services Offerings / Service Details', {'propertyId': ID}, ['propertyId'], 'read-services'),
 ('getRoomAndRateDetails', 'Get Room and Rate Details', {'propertyId': ID, **STAY}, ['propertyId', *STAY], 'read-rates'),
 ('getPromotionsAndDeals', 'Promotions and Deals at Properties', {'propertyId': ID}, ['propertyId'], 'read-promotions'),
 ('compareProperties', 'Compare Properties', {'propertyIds': IDS}, ['propertyIds'], 'compare-properties'),
 ('compareRoomsAndRates', 'Compare Rooms and Rates', {'propertyIds': IDS, **STAY}, ['propertyIds', *STAY], 'compare-rates'),
 ('createBooking', 'Create Booking', {'propertyId': ID, 'roomId': ID, 'rateId': ID, **STAY, 'guest': {'type':'object','additionalProperties':False,'properties':{'name':S,'email':{'type':'string','format':'email','maxLength':254}},'required':['name','email']}, 'confirmed': {'type':'boolean','description':'True only after the user explicitly approves this property, dates and quoted total.'}, 'expectedTotal':{'type':'number','minimum':0}, 'currency':{'type':'string','enum':['SGD']}, 'idempotencyKey': dict(ID, minLength=8, maxLength=64, description='Stable identifier for this booking attempt. Reuse on retries; never change after an uncertain outcome.')}, ['propertyId','roomId','rateId',*STAY,'guest','confirmed','expectedTotal','currency','idempotencyKey'], 'create-booking')
]

HEADER = '''<?xml version="1.0" encoding="UTF-8"?>
<mule xmlns="http://www.mulesoft.org/schema/mule/core" xmlns:mcp="http://www.mulesoft.org/schema/mule/mcp" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.mulesoft.org/schema/mule/core http://www.mulesoft.org/schema/mule/core/current/mule.xsd http://www.mulesoft.org/schema/mule/mcp http://www.mulesoft.org/schema/mule/mcp/current/mule-mcp.xsd">
'''

def main():
    schemas = ROOT / 'src/main/resources/schemas'
    schemas.mkdir(parents=True, exist_ok=True)
    flows, catalog = [HEADER], []
    for name, title, props, required, ref in CATALOG:
        schema = {'$schema':'http://json-schema.org/draft-07/schema#','type':'object','additionalProperties':False,'properties':props,'required':required}
        (schemas / (name + '.json')).write_text(json.dumps(schema, indent=2), encoding='utf-8')
        description = title + '. Uses simulated ODX data in the local profile.'
        if name == 'createBooking':
            description += ' WRITE operation. Creates a reservation only after explicit user approval of property, stay, guest and price. Pass confirmed=true and the quoted expectedTotal, currency and rateId. Use a stable idempotencyKey. Never retry with a new key after a timeout.'
        else:
            description += ' Read-only operation; does not create or change reservations.'
        catalog.append({'name':name,'title':title,'description':description,'inputSchema':schema,'annotations':{'readOnlyHint':name!='createBooking','destructiveHint':False,'idempotentHint':True,'openWorldHint':True}})
        flows.append(f'''  <flow name="{name}">
    <mcp:tool-listener config-ref="Ascott_MCP" name="{name}">
      <mcp:description>{escape(description)}</mcp:description>
      <mcp:parameters-schema><![CDATA[{json.dumps(schema)}]]></mcp:parameters-schema>
      <mcp:responses><mcp:text-tool-response-content text="# [write(payload, 'application/json')]"/></mcp:responses>
      <mcp:on-error-responses><mcp:text-tool-response-content text="# [write({{success: false, correlationId: vars.traceId default correlationId, error: vars.publicError default {{category: 'TECHNICAL', code: 'INTERNAL_ERROR', message: 'Request failed. Contact support with the correlation ID.', retryable: false}}}}, 'application/json')]"/></mcp:on-error-responses>
    </mcp:tool-listener>
    <set-variable variableName="toolName" value="{name}"/>
    <set-variable variableName="args" value="#[payload]"/>
    <flow-ref name="log-start"/>
    <flow-ref name="validate-business-input"/>
    <flow-ref name="{ref}"/>
    <flow-ref name="wrap-success"/>
    <error-handler ref="generic-tool-error-handler"/>
  </flow>
'''.replace('# [', '#['))
    flows.append('</mule>\n')
    (ROOT/'src/main/mule/mcp-tools.xml').write_text(''.join(flows), encoding='utf-8')
    (ROOT/'tool-catalog.json').write_text(json.dumps(catalog, indent=2), encoding='utf-8')

if __name__ == '__main__':
    main()

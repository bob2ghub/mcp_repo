param([switch]$SimulatorOnly)
$ErrorActionPreference = 'Stop'
$taskRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$taskNames = if ($SimulatorOnly) { @('simulator') } else { @('mule', 'simulator') }
foreach ($taskName in $taskNames) {
    $pidFile = Join-Path $taskRoot ".runtime\$taskName.pid"
    if (-not (Test-Path -LiteralPath $pidFile)) { continue }
    $taskPid = [int](Get-Content -LiteralPath $pidFile)
    $taskProcess = Get-CimInstance Win32_Process -Filter "ProcessId=$taskPid"
    if (-not $taskProcess) { continue }
    $marker = if ($taskName -eq 'mule') { Join-Path $taskRoot '.runtime\mule' } else { Join-Path $taskRoot 'simulator\odx_simulator.py' }
    if (-not $taskProcess.CommandLine -or -not $taskProcess.CommandLine.Contains($marker)) {
        throw "PID $taskPid no longer belongs to this project's $taskName. Refusing to stop it."
    }
    Stop-Process -Id $taskPid
    Write-Output "Stopped project $taskName (PID $taskPid)"
}

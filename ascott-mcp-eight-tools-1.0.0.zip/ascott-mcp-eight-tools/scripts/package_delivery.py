"""Build a source-and-deployable delivery ZIP without local runtime state or licenses."""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[1]

def main():
    artifact = ROOT / 'target/ascott-mcp-eight-tools-1.0.0-mule-application.jar'
    if not artifact.exists():
        raise SystemExit('Build the Mule application first.')
    with zipfile.ZipFile(artifact) as jar:
        for name in ('business-flows.xml', 'observability.xml', 'error-handlers.xml', 'mcp-tools.xml', 'global-config.xml'):
            if jar.read(name) != (ROOT / 'src/main/mule' / name).read_bytes():
                raise SystemExit(f'Build is stale: {name}. Rebuild before packaging.')
        if any('.runtime/' in n or '.tools/' in n or n.endswith('.lic') for n in jar.namelist()):
            raise SystemExit('Deployable contains local state or a license; refusing to distribute.')
    files = [ROOT / n for n in ('README.md', 'pom.xml', 'mule-artifact.json', '.project', '.classpath', '.gitignore', '_muleExclude', 'tool-catalog.json')]
    for folder in ('src', 'client', 'simulator', 'scripts', 'tests', 'docs'):
        files.extend(p for p in (ROOT / folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts and not p.name.endswith(('.lic', '.pyc', '.local.properties')))
    files.append(artifact)
    out = ROOT / 'dist'
    out.mkdir(exist_ok=True)
    manifest = {p.relative_to(ROOT).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
    destination = out / 'ascott-mcp-eight-tools-1.0.0.zip'
    with zipfile.ZipFile(destination, 'w', zipfile.ZIP_DEFLATED) as bundle:
        for p in sorted(files):
            bundle.write(p, ROOT.name + '/' + p.relative_to(ROOT).as_posix())
        bundle.writestr(ROOT.name + '/SHA256SUMS.json', json.dumps(manifest, indent=2))
    print(f'Created {destination} ({destination.stat().st_size:,} bytes; {len(files)} files)')

if __name__ == '__main__':
    main()

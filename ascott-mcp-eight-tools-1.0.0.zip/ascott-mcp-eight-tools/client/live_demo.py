"""Local browser demo of actual Mule MCP calls. Run: python client/live_demo.py."""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import json
from urllib.request import urlopen
from mcp_client import MCPClient

class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def send(self, status, body, mime='application/json'):
        data = body if isinstance(body, bytes) else json.dumps(body).encode()
        self.send_response(status)
        self.send_header('Content-Type', mime)
        self.send_header('Content-Length', str(len(data)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        if self.path == '/':
            return self.send(200, Path(__file__).with_name('live_demo.html').read_bytes(), 'text/html; charset=utf-8')
        if self.path == '/api/status':
            try:
                with urlopen('http://127.0.0.1:8081/health', timeout=3) as r:
                    mule = json.load(r)
                with urlopen('http://127.0.0.1:8091/health', timeout=3) as r:
                    odx = json.load(r)
                client = MCPClient()
                try:
                    initialized = client.initialize()
                    tools = client.list_tools()
                finally:
                    client.close()
                return self.send(200, {'mule': mule, 'odx': odx, 'initialize': initialized, 'tools': tools})
            except Exception as exc:
                return self.send(502, {'error': str(exc)})
        self.send(404, {'error': 'Not found'})

    def do_POST(self):
        if self.path != '/api/call':
            return self.send(404, {'error': 'Not found'})
        if self.headers.get('Origin') not in ('http://127.0.0.1:8092', 'http://localhost:8092'):
            return self.send(403, {'error': 'Use the local demo page'})
        client = MCPClient()
        try:
            length = int(self.headers.get('Content-Length', '0'))
            if not 0 < length <= 16384:
                raise ValueError('Invalid request size')
            args = json.loads(self.rfile.read(length))
            with urlopen('http://127.0.0.1:8081/health', timeout=3) as r:
                if json.load(r).get('mode') != 'SIMULATOR':
                    raise ValueError('Live demo is restricted to SIMULATOR mode')
            client.initialize()
            result = client.call(args['name'], args['arguments'])
            self.send(200, {'result': result, 'decodedContent': client.content(result)})
        except Exception as exc:
            self.send(502, {'error': str(exc)})
        finally:
            client.close()

if __name__ == '__main__':
    print('Live Mule MCP demo: http://127.0.0.1:8092', flush=True)
    ThreadingHTTPServer(('127.0.0.1', 8092), Handler).serve_forever()

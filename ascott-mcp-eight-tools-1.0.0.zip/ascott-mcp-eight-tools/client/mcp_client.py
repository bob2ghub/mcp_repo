"""Dependency-free Streamable HTTP MCP sample client; no OpenAI API key needed."""
import argparse
import json
import os
import sys
from datetime import date, timedelta
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.error import HTTPError
import uuid

class MCPError(RuntimeError):
    pass

class MCPClient:
    def __init__(self,url='http://127.0.0.1:8081/mcp',token=None):
        self.url=url
        self.token=token
        self.session=None
        self.version=None
        self.sequence=0

    def rpc(self,method,params=None,notification=False):
        self.sequence+=1
        request={'jsonrpc':'2.0','method':method}
        if params is not None:
            request['params']=params
        if not notification:
            request['id']=self.sequence
        headers={'Content-Type':'application/json','Accept':'application/json, text/event-stream'}
        if self.session:
            headers['Mcp-Session-Id']=self.session
        if self.version:
            headers['MCP-Protocol-Version']=self.version
        if self.token:
            headers['Authorization']='Bearer '+self.token
        try:
            response=urlopen(Request(self.url,json.dumps(request).encode(),headers),timeout=35)
        except HTTPError as exc:
            raise MCPError(f'HTTP {exc.code}: {exc.read().decode(errors="replace")}') from exc
        with response:
            self.session=response.headers.get('Mcp-Session-Id',self.session)
            if notification:
                return None
            if 'text/event-stream' in response.headers.get('Content-Type',''):
                data=[]
                for raw in response:
                    line=raw.decode().rstrip('\r\n')
                    if line.startswith('data:'):
                        data.append(line[5:].lstrip())
                    elif not line and data:
                        event=json.loads('\n'.join(data))
                        data=[]
                        if event.get('id')==request['id']:
                            body=event
                            break
                else:
                    raise MCPError('SSE ended without the matching JSON-RPC response')
            else:
                body=json.load(response)
        if body.get('jsonrpc')!='2.0' or body.get('id')!=request['id']:
            raise MCPError('Invalid JSON-RPC response or mismatched request ID')
        if 'error' in body:
            raise MCPError(json.dumps(body['error']))
        return body['result']

    def initialize(self):
        result=self.rpc('initialize',{'protocolVersion':'2025-06-18','capabilities':{},'clientInfo':{'name':'ascott-sample-client','version':'1.0.0'}})
        self.version=result['protocolVersion']
        self.rpc('notifications/initialized',notification=True)
        return result

    def list_tools(self):
        tools=[]
        cursor=None
        while True:
            result=self.rpc('tools/list',{'cursor':cursor} if cursor else {})
            tools.extend(result['tools'])
            cursor=result.get('nextCursor')
            if not cursor:
                return tools

    def call(self,name,args):
        return self.rpc('tools/call',{'name':name,'arguments':args})

    @staticmethod
    def content(result):
        if result.get('structuredContent') is not None:
            return result['structuredContent']
        text='\n'.join(c['text'] for c in result.get('content',[]) if c['type']=='text')
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            # MCP allows plain text, including connector-level schema errors.
            return {'text':text}

    def close(self):
        if self.session:
            headers={'Mcp-Session-Id':self.session,'MCP-Protocol-Version':self.version}
            if self.token:
                headers['Authorization']='Bearer '+self.token
            try:
                with urlopen(Request(self.url,headers=headers,method='DELETE'),timeout=5):
                    pass
            except HTTPError as exc:
                if exc.code not in (404,405):
                    raise
            self.session=None

def demo(client):
    """Exercise all eight tools, creating exactly one explicitly simulated reservation."""
    start=date.today()+timedelta(days=30+uuid.uuid4().int%2000)
    stay={'checkIn':start.isoformat(),'checkOut':(start+timedelta(days=2)).isoformat(),'adults':2}
    calls=[('findPropertiesByLocation',{'location':'Singapore'}),('getPropertyDetails',{'propertyId':'SG-001'}),('getServiceOfferings',{'propertyId':'SG-001'}),('getRoomAndRateDetails',{'propertyId':'SG-001',**stay}),('getPromotionsAndDeals',{'propertyId':'SG-001'}),('compareProperties',{'propertyIds':['SG-001','SG-002']}),('compareRoomsAndRates',{'propertyIds':['SG-001','SG-002'],**stay})]
    results={}
    for name,args in calls:
        result=client.call(name,args)
        if result.get('isError'):
            raise MCPError(json.dumps(result))
        results[name]=client.content(result)
        print(f'PASS {name}')
    if results['getRoomAndRateDetails']['mode']!='SIMULATOR':
        raise MCPError('The demo will create bookings only in SIMULATOR mode')
    room=results['getRoomAndRateDetails']['data']['rooms'][0]
    args={'propertyId':'SG-001',**stay,'roomId':room['roomId'],'rateId':room['rateId'],'expectedTotal':room['total'],'currency':room['currency'],'guest':{'name':'Demo Guest','email':'demo@example.com'},'confirmed':True,'idempotencyKey':'demo-'+uuid.uuid4().hex}
    booked=client.call('createBooking',args)
    if booked.get('isError'):
        raise MCPError(json.dumps(booked))
    results['createBooking']=client.content(booked)
    print('PASS createBooking (SIMULATION ONLY)')
    return results

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--url',default='http://127.0.0.1:8081/mcp')
    parser.add_argument('--list',action='store_true')
    parser.add_argument('--demo',action='store_true')
    parser.add_argument('--tool')
    parser.add_argument('--args',default='{}',help='JSON arguments')
    parser.add_argument('--args-file',type=Path)
    parser.add_argument('--output',type=Path)
    options=parser.parse_args()
    client=MCPClient(options.url,os.environ.get('MCP_TOKEN'))
    try:
        client.initialize()
        if options.demo:
            result=demo(client)
        elif options.tool:
            args=json.loads(options.args_file.read_text() if options.args_file else options.args)
            result=client.call(options.tool,args)
        else:
            result=client.list_tools()
        serialized=json.dumps(result,indent=2)
        if options.output:
            options.output.parent.mkdir(parents=True,exist_ok=True)
            options.output.write_text(serialized,encoding='utf-8')
        print(serialized)
        if isinstance(result,dict) and result.get('isError'):
            sys.exit(1)
    finally:
        client.close()

if __name__=='__main__':
    main()

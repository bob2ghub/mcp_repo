# Connect the Mule MCP server to ChatGPT

The local endpoint is `http://127.0.0.1:8081/mcp`, using Streamable HTTP. The Python client verifies this endpoint directly. A ChatGPT account connection is a separate step and has not been created automatically.

ChatGPT must be able to reach the endpoint. Use a Secure MCP Tunnel for private/local development, or a deployed HTTPS endpoint. The ChatGPT service cannot reach your laptop through a bare localhost URL. See the official [connection guide](https://developers.openai.com/plugins/deploy/connect-chatgpt) and [Secure MCP Tunnel guide](https://developers.openai.com/api/docs/guides/secure-mcp-tunnels).

In a supported ChatGPT account, enable Developer mode under Settings > Security and login. In Plugins, create a connection, choose the endpoint or Tunnel option, and follow the account-specific setup. For a tunnel, route to the local Mule `/mcp` endpoint. For HTTPS, preserve `/mcp`, JSON bodies, Accept headers, MCP session/protocol headers, and streaming responses. Use the authentication mode appropriate to your deployed gateway. This project's local endpoint has no MCP user authentication; configure user authentication and authorization before any real booking integration.

After connecting, verify that all eight names in `tool-catalog.json` appear. Select the connection in a conversation and try:

1. “Find the demo properties in Singapore and compare SG-001 and SG-002.”
2. “Show services, promotions and rates for SG-001 for a two-night future stay for two adults.”
3. “Prepare a simulated booking using that quote. Ask me to approve the property, dates and total before creating it.”
4. After confirming the details, approve the simulated booking; the result must say `CONFIRMED_SIMULATION`.

The native connector publishes JSON input schemas and descriptions. This version's live catalog does not include the proposed annotations in `tool-catalog.json`; expect ChatGPT's conservative confirmation behavior. The booking tool enforces `confirmed=true`, quote fields and a stable idempotency key. Developer-mode discovery is not equivalent to marketplace submission approval, which can require additional metadata and authentication work.

No public endpoint, tunnel pairing or ChatGPT account permission has been configured in this project. Those account/network steps remain necessary to test directly inside ChatGPT; the bundled sample client runs the full MCP-to-Mule-to-dummy-ODX path locally.

# Shared exception handling and logging

Every MCP listener has `<error-handler ref="generic-tool-error-handler"/>`. Functional failures invoke `generic-functional-exception`; all other Mule errors invoke `generic-technical-exception`. Both invoke `log-failure`. The handlers use `on-error-propagate`, allowing the native connector to return `isError: true`. Errors are never returned as successful tool text.

| Condition | Category / public code | Caller behavior |
|---|---|---|
| Invalid dates or business inputs | FUNCTIONAL / VALIDATION | Correct arguments |
| Booking not explicitly confirmed | FUNCTIONAL / CONFIRMATION_REQUIRED | Obtain approval of the quoted booking |
| Missing property | FUNCTIONAL / NOT_FOUND | Select a valid property |
| ODX 400 | FUNCTIONAL / BAD_REQUEST | Correct input |
| ODX 409 (price, inventory or idempotency conflict) | FUNCTIONAL / CONFLICT | Recheck quote and original key |
| ODX 422 | FUNCTIONAL / VALIDATION | Correct business input |
| Read timeout, connectivity failure, 429, 502, 503 or 504 | TECHNICAL / DOWNSTREAM_UNAVAILABLE | May retry later with bounded backoff |
| ODX 401 or 403 | TECHNICAL / DOWNSTREAM_AUTHENTICATION | Operator fixes downstream access |
| Parallel comparison fails | TECHNICAL / COMPARISON_FAILED | No partial results; check IDs and downstream availability |
| Booking timeout, connection loss or selected 5xx responses | TECHNICAL / BOOKING_OUTCOME_UNKNOWN | Reconcile, or retry identical input with the original key |
| Unexpected error | TECHNICAL / INTERNAL_ERROR | Investigate using correlation ID |

Native connector input-schema failures happen before the Mule flow. They can return plain-text MCP tool errors or JSON-RPC errors, without the application envelope or application audit event. The sample client supports both. Unknown tool names are protocol errors. The generic business error contract applies to failures after entering the Mule flow.

Example tool error content (inside MCP `content[0].text`):

```json
{"success":false,"correlationId":"request-id","error":{"category":"FUNCTIONAL","code":"CONFLICT","message":"Booking conflict: verify the current rate, availability and original idempotency key.","retryable":false}}
```

The simulator uses SQLite transactions for durable same-key retries and atomic per-night capacity checks. Same key and same request returns the same reservation; changed arguments return a conflict. Mule does not automatically retry bookings. Explicit confirmation is a caller assertion validated by the API; this local unauthenticated demo does not provide independent proof of human consent.

`log-start`, `log-success`, `log-failure`, and downstream log components record JSON events with correlation ID, tool, outcome, status and duration where applicable. They omit input payloads, guest details, authorization headers and downstream response bodies. The correlation ID is forwarded to ODX as `X-Correlation-ID`. Native connector/runtime diagnostics also appear in the console.

Mule's application audit file is `${mule.base}/logs/ascott-mcp-audit.jsonl`, rotating at 10 MB with 5 archives. Portable launch uses `.runtime/mule/logs`; Studio uses its launch's Mule base. The simulator writes `logs/odx-audit.jsonl`, rotating at 5 MB with 3 archives. Portable startup output is in `logs/mule-console.log`. Schema failures do not enter the application's logger; platform access logging and monitoring are additional deployment concerns.

For deterministic failure demonstrations, call `getPropertyDetails` with `TECH-503` or `TECH-TIMEOUT`. These reserved simulator IDs produce a service failure or exceed Mule's five-second downstream timeout. Use a nonexistent ordinary ID to exercise functional not-found handling. Do not log full payloads when investigating failures.

# Assumed dummy ODX REST contract

Base URL: `http://127.0.0.1:8091/odx/v1`. Use `Authorization: Bearer local-simulator` and `X-Correlation-ID`. This token is a dummy local value. GET `/health` does not require it.

| Method / path | Inputs | Successful response |
|---|---|---|
| GET `/properties` | query `location`, optional `limit` 1–50 | `properties`, `total`, `simulated` |
| GET `/properties/{propertyId}` | path ID | property details, amenities, times |
| GET `/properties/{propertyId}/services` | path ID | `propertyId`, `services` |
| GET `/properties/{propertyId}/rates` | query `checkIn`, `checkOut`, `adults` | `propertyId`, dates, occupancy, `rooms` with rate IDs and totals |
| GET `/properties/{propertyId}/promotions` | path ID | `propertyId`, informational `promotions` |
| POST `/bookings` | JSON matching the createBooking input schema; matching `Idempotency-Key` header | 201, stable simulated booking result |

The booking request body must be a JSON object with Content-Length and at most 16 KiB. Mule uses a non-streamed JSON body for compatibility with this standard-library simulator. HTTP 400 indicates invalid input, 401 a wrong simulator token, 404 missing data, and 409 a quote, inventory or idempotency conflict. Errors use `{"error":{"code":"...","message":"..."}}`. All success data is simulated.

Durable state is `.runtime/bookings.db`. It stores a request fingerprint and a response without guest details. Do not delete the database while the simulator is running. These demo records are local and create no real reservations.

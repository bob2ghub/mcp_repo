# Local verification — 15 September 2026

Executed against the actual native Mule application launched from Anypoint Studio, with the Python ODX simulator on the same machine.

- Runtime: Mule Server 4.12.3 EE, Java 17.0.12, native MCP connector 1.7.0, HTTP connector 1.12.1.
- Maven package succeeds with Mule Maven Plugin 4.10.1 and Mule 4.12.0 build framework validation.
- `test-results.txt`: all 10 end-to-end tests pass, including read/compare tools, confirmation, quote conflict, booking retry identity, four concurrent identical booking requests, schema rejection, missing properties, dates, downstream 503 and timeout handling.
- `demo-results.json`: the sample MCP client successfully executes all eight tools and creates one fictional reservation.
- `audit-sample.json`: representative live Studio application audit events. All 122 audit lines available at inspection parsed as JSON objects; demo guest email and the dummy authorization token were absent.
- The packaged JAR's five Mule XML configurations are compared byte-for-byte to the final source before delivery packaging.

Tests use simulated data and randomly selected future dates; booking records are persisted locally. This is functional local integration verification, not a production load test or a claim that all possible faults have been tested. Real ODX and a ChatGPT account/tunnel connection have not been exercised.

# Live verification - 18 September 2026

Both applications are running in Anypoint Studio 7.28, with Mule Server 4.12.3 EE and Studio-JDK-17. The active `ascott-mcp-eight-tools` launch selects both `ascott-mcp-eight-tools` and `ascott.mcp.tool-calls.xapi`.

## Verified results

| Verification | Result | Evidence |
|---|---|---|
| Studio compilation and packaging | Both applications passed | Studio Maven console |
| Direct experience API suite | 6 tests passed | [XAPI test output](studio-xapi-tests.log) |
| Native MCP end-to-end suite | 10 tests passed | [MCP test output](studio-mcp-tests.log) |
| Dummy process service suite | 2 tests passed, including all eight endpoints | [Process test output](studio-process-tests.log) |
| Sample MCP client | All eight tools succeeded | [Full responses](live-demo-results.json) |
| Actual downstream HTTP requests | All eight MCP result correlation IDs matched process receipt | [Routing proof](live-routing-proof.json) |

The XAPI suite verifies all eight APIkit routes, successful response status and correlation headers, JSON schema validation, unknown resources, unsupported methods/media types, missing properties, downstream 503, and timeouts. The MCP suite verifies discovery, seven read/comparison tools, booking, malformed arguments, date validation, explicit confirmation, quote mismatch, durable identical retries, concurrent retries, changed-input conflicts, comparison failures, technical failures and unknown tools.

The tests call the running Mule applications over HTTP. The Python process service supplies dummy responses behind the experience API. No real ODX endpoints, payments, emails or hotel reservations are used.

## Fixes applied during Studio setup

- Captured `attributes.statusCode` immediately after each process HTTP request and passed it to the shared response checker as `vars.processStatus`, clearing Studio's DataWeave reference errors.
- Set both project build paths/compiler settings to Java 17 and project encoding to UTF-8; restored missing source directories.
- Included both projects in one Studio launch with Mule 4.12.3 and Studio-JDK-17.
- Set `X-Correlation-ID` explicitly in the listener's final success/error response headers because APIkit resets its outbound header map during routing.
- Retried a transient Windows dependency-file lock during packaging; both Studio builds subsequently passed.

## Run again

Start the process service from the experience project with `python scripts\stack.py process`. In Studio, open **Run Configurations > Mule Applications > ascott-mcp-eight-tools**, verify both projects are selected, and click **Run** once. Wait for both applications to show `DEPLOYED`. A reusable [launch configuration](ascott-local-stack.launch) is included without runtime-agent tokens.

```powershell
python scripts\stack.py status
python tests\test_xapi.py
python ..\ascott-mcp-eight-tools\tests\test_e2e.py
python ..\ascott-mcp-eight-tools\client\mcp_client.py --demo
```

MCP: `http://127.0.0.1:8081/mcp`. XAPI: `http://127.0.0.1:8082/api/v1`. Process stub: `http://127.0.0.1:8093`. Live demo: `http://127.0.0.1:8092` (start `client/live_demo.py` in the MCP project after a restart).

The optional portable launcher still encounters local license validation failure. This does not affect the verified Studio launch. The package contains no license files, runtime-agent tokens, local runtime directories or booking databases. ChatGPT connectivity beyond this local demo requires the separately documented HTTPS deployment/connection setup.

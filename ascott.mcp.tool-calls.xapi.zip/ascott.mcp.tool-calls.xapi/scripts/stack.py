"""Build/start the MCP -> APIkit XAPI -> process stub dry-run stack."""
from pathlib import Path
import importlib.util,sys,argparse,shutil,subprocess,json
ROOT=Path(__file__).resolve().parents[1]
MCP=ROOT.parent/'ascott-mcp-eight-tools'
spec=importlib.util.spec_from_file_location('local',MCP/'scripts/local.py')
local=importlib.util.module_from_spec(spec);spec.loader.exec_module(local)

def mock():
    health=local.healthy(8093)
    if health:
        if health.get('service')!='ascott-process-api-stub': raise SystemExit('Port 8093 belongs to a different service')
        return
    if not local.port_free(8093): raise SystemExit('Port 8093 is occupied')
    with (ROOT/'logs/process-console.log').open('ab') as log:
        proc=subprocess.Popen([sys.executable,str(ROOT/'scripts/process_stub.py')],stdout=log,stderr=log,stdin=subprocess.DEVNULL,creationflags=subprocess.CREATE_NO_WINDOW)
    (ROOT/'.runtime/process.pid').write_text(str(proc.pid))
    print('Process stub started:',proc.pid)

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('command',choices=['build','start','status','process']);parser.add_argument('--studio',type=Path,default=local.DEFAULT_STUDIO);opts=parser.parse_args()
    (ROOT/'logs').mkdir(exist_ok=True);(ROOT/'.runtime').mkdir(exist_ok=True)
    if opts.command=='process':
        mock()
    elif opts.command=='build':
        for project in [ROOT,MCP]:
            local.ROOT=project
            code=local.build(opts.studio)
            if code: raise SystemExit(code)
    elif opts.command=='start':
        local.ROOT=MCP
        if local.healthy(8081) or local.healthy(8082):
            raise SystemExit('A Mule app is already running. Use Studio stop/redeploy, or stop the owned portable stack before starting a new stack.')
        artifact=ROOT/'target/ascott.mcp.tool-calls.xapi-1.0.0-mule-application.jar'
        if not artifact.exists(): raise SystemExit('Build first')
        mock();apps=MCP/'.runtime/mule/apps';apps.mkdir(parents=True,exist_ok=True)
        shutil.copy2(artifact,apps/artifact.name)
        local.start_simulator=mock
        local.start(opts.studio)
    else:
        print(json.dumps({name:local.healthy(port) for name,port in [('mcp',8081),('xapi',8082),('process',8093)]},indent=2))

if __name__=='__main__': main()

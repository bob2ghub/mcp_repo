"""Package both sibling Mule projects, contracts, dummy process service and JARs."""
from pathlib import Path
import zipfile,hashlib,json
X=Path(__file__).resolve().parents[1]
M=X.parent/'ascott-mcp-eight-tools'
out=X/'dist';out.mkdir(exist_ok=True)
files=[]
for root in [M,X]:
    for name in ['README.md','pom.xml','mule-artifact.json','.project','.classpath','.gitignore','_muleExclude','tool-catalog.json']:
        p=root/name
        if p.exists():files.append(p)
    for folder in ['src','client','scripts','simulator','tests','docs','.settings']:
        files.extend(p for p in (root/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts and not p.name.endswith(('.lic','.pyc','.local.properties')))
    jar=root/'target'/f'{root.name}-1.0.0-mule-application.jar'
    with zipfile.ZipFile(jar) as z:
        for source in (root/'src/main/mule').glob('*.xml'):
            assert z.read(source.name)==source.read_bytes(),f'Stale build: {source}'
        for source in (root/'src/main/resources').rglob('*'):
            if source.is_file(): assert z.read(source.relative_to(root/'src/main/resources').as_posix())==source.read_bytes(),f'Stale resource: {source}'
        assert not any(n.endswith('.lic') or '.runtime/' in n or '.tools/' in n for n in z.namelist())
    files.append(jar)
path=out/'ascott-mcp-xapi-dry-run.zip'
hashes={p.relative_to(X.parent).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as z:
    for p in files:z.write(p,p.relative_to(X.parent).as_posix())
    for root in [M,X]:
        for directory in ['src/main/java','src/test/java','src/test/resources','src/test/munit']:
            z.writestr(root.name+'/'+directory+'/',b'')
    z.writestr('SHA256SUMS.json',json.dumps(hashes,indent=2))
with zipfile.ZipFile(path) as z:assert z.testzip() is None
print(f'Created {path}: {len(files)} files, {path.stat().st_size:,} bytes')

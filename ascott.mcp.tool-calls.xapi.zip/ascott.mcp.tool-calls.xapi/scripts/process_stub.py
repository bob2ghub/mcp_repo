"""Dry-run process APIs on 8093. Fictional responses; no calls to real ODX."""
from pathlib import Path
import sys,json,time,logging,sqlite3
from concurrent.futures import ThreadPoolExecutor
from http.server import ThreadingHTTPServer
from urllib.parse import urlsplit
from logging.handlers import RotatingFileHandler

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT.parent/'ascott-mcp-eight-tools/simulator'))
import odx_simulator as dummy

def dispatch(name,args,db):
    pid=args.get('propertyId')
    if pid=='TECH-503': dummy.fail(503,'UNAVAILABLE','Simulated process outage')
    if pid=='TECH-TIMEOUT':
        time.sleep(6)
        dummy.fail(504,'TIMEOUT','Simulated process timeout')
    if name=='findPropertiesByLocation':
        location=args.get('location','').strip().casefold()
        if not location: dummy.fail(400,'VALIDATION','Location is required')
        matches=[p for p in dummy.PROPERTIES if location in (p['city']+' '+p['country']).casefold()]
        return {'properties':matches[:args.get('limit',20)],'total':len(matches),'simulated':True}
    if name in ('compareProperties','compareRoomsAndRates'):
        tool='getPropertyDetails' if name=='compareProperties' else 'getRoomAndRateDetails'
        with ThreadPoolExecutor(max_workers=5) as pool:
            results=list(pool.map(lambda p:dispatch(tool,{**args,'propertyId':p},db),args['propertyIds']))
        return {'properties':results,'comparisonPolicy':'ALL_OR_NOTHING'}
    if name=='createBooking': return dummy.create_booking(db,args,args.get('idempotencyKey'))
    if name not in ('getPropertyDetails','getServiceOfferings','getRoomAndRateDetails','getPromotionsAndDeals'):
        dummy.fail(404,'NOT_FOUND','Unknown process endpoint')
    prop=dummy.property_by_id(pid)
    if name=='getPropertyDetails': return {**prop,'description':'Fictional process-API property response.','checkInTime':'15:00','checkOutTime':'11:00','simulated':True}
    if name=='getServiceOfferings': return {'propertyId':pid,'services':[{'name':a,'included':True} for a in prop['amenities']],'simulated':True}
    if name=='getRoomAndRateDetails': return dummy.quote(prop,args)
    return {'propertyId':pid,'promotions':[{'promotionId':'DEMO-LONG-STAY','name':'Long stay information','description':'Dummy process offer, not applied to FLEX rates.','automaticallyApplied':False}],'simulated':True}

class Handler(dummy.Handler):
    def do_GET(self):
        self.reply(200 if self.path=='/health' else 404,{'status':'UP','service':'ascott-process-api-stub','mode':'SIMULATOR'})
    def do_POST(self):
        began=time.monotonic(); status=500; tool='unknown'
        trace=self.headers.get('X-Correlation-ID','')
        try:
            prefix='/process/v1/tool-calls/'
            path=urlsplit(self.path).path
            if not path.startswith(prefix): dummy.fail(404,'NOT_FOUND','Unknown endpoint')
            tool=path[len(prefix):]
            length=int(self.headers.get('Content-Length','0'))
            if not 0<length<=16384: dummy.fail(400,'INVALID_BODY','JSON object required')
            args=json.loads(self.rfile.read(length))
            if not isinstance(args,dict): dummy.fail(400,'INVALID_BODY','JSON object required')
            if tool=='createBooking' and self.headers.get('Idempotency-Key')!=args.get('idempotencyKey'):
                dummy.fail(400,'INVALID_KEY','Idempotency header must match the body')
            data=dispatch(tool,args,self.server.db)
            status=201 if tool=='createBooking' else 200
            self.reply(status,data)
        except dummy.BusinessError as exc:
            status=exc.status; self.reply(status,{'error':{'code':exc.code,'message':exc.message}})
        except (ValueError,KeyError,TypeError):
            status=400;self.reply(status,{'error':{'code':'INVALID_REQUEST','message':'Malformed process request'}})
        except Exception:
            self.reply(500,{'error':{'code':'INTERNAL_ERROR','message':'Process stub failed'}})
        finally:
            logging.getLogger('process.audit').info(json.dumps({'event':'process.request','tool':tool,'correlationId':trace,'status':status,'durationMs':round((time.monotonic()-began)*1000)}))

if __name__=='__main__':
    (ROOT/'.runtime').mkdir(exist_ok=True);(ROOT/'logs').mkdir(exist_ok=True)
    log=logging.getLogger('process.audit');log.setLevel(logging.INFO)
    log.addHandler(RotatingFileHandler(ROOT/'logs/process-audit.jsonl',maxBytes=5_000_000,backupCount=3))
    db=ROOT/'.runtime/process-bookings.db';dummy.init_db(db)
    server=ThreadingHTTPServer(('127.0.0.1',8093),Handler);server.db=db
    print('Dummy process APIs listening at http://127.0.0.1:8093/process/v1/tool-calls',flush=True)
    server.serve_forever()

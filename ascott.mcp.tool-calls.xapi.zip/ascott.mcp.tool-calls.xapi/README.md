# ascott.mcp.tool-calls.xapi

Native Mule 4 experience API with RAML 1.0, an APIkit router, eight routing flows and an HTTP Request operation in every route. Dummy process APIs are separate HTTP services for local dry runs.

Verified live in Anypoint Studio on 18 September 2026: both applications are deployed, all eight MCP tools reach the experience API and process stub, and all 6 XAPI tests and 10 MCP tests pass. See [verification evidence](docs/verification.md).

```mermaid
flowchart LR
  C[MCP client] --> M[Mule MCP server :8081/mcp]
  M --> X[XAPI :8082/api/v1/tool-calls]
  X --> R[RAML validation and APIkit router]
  R --> F[Eight routing flows]
  F --> P[HTTP process API stub :8093]
```

## Contract and routing

The source of truth is `src/main/resources/api/ascott.mcp.tool-calls.xapi.raml`. It includes eight JSON request schemas, eight response schemas, examples, a common error type, HTTP error statuses and the optional correlation header. JSON is required. Request schemas reject unknown fields and constrain property IDs, dates, occupancy and booking inputs.

The MCP server translates `tools/call` into POST requests containing the tool's **arguments object**. The XAPI is a REST API; MCP initialization, discovery and JSON-RPC stay on the MCP server.

| MCP tool | XAPI POST path, after `/api/v1` | Flow | Process POST path, after `/process/v1/tool-calls` |
|---|---|---|---|
| findPropertiesByLocation | /tool-calls/findPropertiesByLocation | route-findPropertiesByLocation | /findPropertiesByLocation |
| getPropertyDetails | /tool-calls/getPropertyDetails | route-getPropertyDetails | /getPropertyDetails |
| getServiceOfferings | /tool-calls/getServiceOfferings | route-getServiceOfferings | /getServiceOfferings |
| getRoomAndRateDetails | /tool-calls/getRoomAndRateDetails | route-getRoomAndRateDetails | /getRoomAndRateDetails |
| getPromotionsAndDeals | /tool-calls/getPromotionsAndDeals | route-getPromotionsAndDeals | /getPromotionsAndDeals |
| compareProperties | /tool-calls/compareProperties | route-compareProperties | /compareProperties |
| compareRoomsAndRates | /tool-calls/compareRoomsAndRates | route-compareRoomsAndRates | /compareRoomsAndRates |
| createBooking | /tool-calls/createBooking | route-createBooking | /createBooking |

`global-config.xml` contains the listener, APIkit configuration, explicit flow mappings, default APIkit router and API console. `tool-routes.xml` contains all eight routing flows. Each calls `Process_HTTP`, forwards JSON and `X-Correlation-ID`, and checks the process response. Booking also forwards its body key as `Idempotency-Key`. Successful process data passes through unchanged; booking returns HTTP 201 and reads/comparisons return 200. The MCP server adds its existing success envelope.

## Run the full dry-run stack

Keep this project beside `ascott-mcp-eight-tools`. Requirements are Python 3.10+, Studio with Java 17 and Mule 4.12 EE, and available Maven dependencies. The configured installation is `C:\AnypointStudio28\AnypointStudio`. Use `--studio` to override it.

The verified launch is **Anypoint Studio > Run Configurations > Mule Applications > ascott-mcp-eight-tools**. Both projects are selected, with **Mule Server 4.12.3 EE** and **Studio-JDK-17**. Click **Run** once and wait for both applications to show `DEPLOYED`. A reusable configuration is provided in `docs/ascott-local-stack.launch`.

Start the dummy process service first from this project directory:

```powershell
python scripts\stack.py process
```

Check all three services and run the sample client:

```powershell
python scripts\stack.py status
python ..\ascott-mcp-eight-tools\client\mcp_client.py --demo
```

Studio runtime logs are under `C:\AnypointStudio28\AnypointStudio\plugins\org.mule.tooling.server.4.12.ee_7.25.0.202609031949\mule\logs`. Both projects use Java 17 and UTF-8. The shared response checker receives an explicitly captured HTTP status, and the HTTP listener sets the response correlation header after APIkit routing.

The optional portable `stack.py start` launcher still fails license validation on this machine. Use the working Studio launch above. `stack.py build` builds both projects separately; avoid command-line builds while Studio is also building them. A transient Windows dependency-file lock was resolved by a Studio rebuild.

| URL | Purpose |
|---|---|
| http://127.0.0.1:8081/mcp | Existing MCP client endpoint |
| http://127.0.0.1:8082/api/v1 | Experience API REST base |
| http://127.0.0.1:8082/console/ | RAML API console |
| http://127.0.0.1:8082/health | XAPI liveness |
| http://127.0.0.1:8093/health | Process-stub liveness |

For Studio, import both sibling projects via **Anypoint Studio project from File System**, select Java 17 and Mule 4.12, then run both. Start only the process stub with `python scripts\stack.py process`. Stop the portable runtime before running the same apps in Studio so the ports remain available. No Studio workspace or global JRE settings need to change for the source import.

## Test

```powershell
python tests\test_xapi.py
python ..\ascott-mcp-eight-tools\tests\test_e2e.py
python ..\ascott-mcp-eight-tools\client\mcp_client.py --demo
```

The direct XAPI suite calls all eight REST routes, verifies downstream audit records with the same correlation ID, checks APIkit schema/path/method/media-type rejection, and exercises functional and technical failures. The original MCP suite then tests the complete new chain, including durable and concurrent booking retries.

Example direct REST call:

```powershell
Invoke-RestMethod -Method Post -Uri 'http://127.0.0.1:8082/api/v1/tool-calls/getPropertyDetails' -ContentType 'application/json' -Body '{"propertyId":"SG-001"}'
```

The browser demo also uses the new chain:

```powershell
python ..\ascott-mcp-eight-tools\client\live_demo.py
```

Open http://127.0.0.1:8092 and choose **Run all 8 tools**.

## Dummy process responses and replacement

`scripts/process_stub.py` exposes eight HTTP endpoints on loopback port 8093. It reuses the existing fictional property/rate/booking functions in the sibling project's simulator module, without making ODX HTTP calls. Responses contain simulated property data, services, promotions, room rates, comparisons and `CONFIRMED_SIMULATION` bookings. No payments or emails are sent. SQLite in `.runtime/process-bookings.db` preserves identical booking retries and enforces simulated inventory.

Process orchestration belongs behind the experience API: the dummy process comparison endpoints aggregate their dummy property/rate reads. The XAPI itself performs exactly one HTTP process request per tool. Its response examples are sample values, not fixed responses substituted in the routing flows.

Update `process.protocol`, `process.host`, `process.port` and `process.basePath` in `application.properties` for a real process API implementing this assumed contract. If tools go to different services, assign separate request configurations to their routes. Real process contracts and credentials are not supplied, so production mappings, authentication and authorization remain deployment work. All local listeners bind to 127.0.0.1.

## Shared error handling and logging

`generic-xapi-error-handler` references reusable `generic-functional-exception` and `generic-technical-exception` flows. APIkit returns 400/404/405/406/415/501 for contract/routing failures. Process business failures preserve 400/404/409/422. Process transport/server failures return 502, while a five-second process timeout returns 504. Error responses contain `success=false`, correlation ID and an error category/code/message/retryability flag.

Booking transport failures are marked `BOOKING_OUTCOME_UNKNOWN`; callers must reconcile or retry identical input with the original key. The MCP requester waits ten seconds, longer than the XAPI process timeout, and propagates the XAPI's normalized error using native MCP `isError=true`. Schema failures rejected before a native MCP flow retain the connector's protocol-level format.

MCP and XAPI audit logs include correlation ID, tool and outcome; XAPI start/success events include elapsed time. Payloads, guest details and authorization headers are omitted. The same ID appears in `logs/process-audit.jsonl`. XAPI audit files rotate at 10 MB with five archives; the process-stub audit rotates at 5 MB with three archives.

References: [APIkit XML configuration](https://docs.mulesoft.com/apikit/latest/apikit-4-xml-reference), [APIkit scaffolding](https://docs.mulesoft.com/apikit/latest/apikit-4-scaffolding-reference).

"""Dry-run HTTP process service tests, independent of Mule licensing."""
import unittest,json,uuid
from pathlib import Path
from datetime import date,timedelta
from urllib.request import Request,urlopen
from urllib.error import HTTPError
ROOT=Path(__file__).resolve().parents[1]

class ProcessStub(unittest.TestCase):
    def send(self,name,args):
        req=Request('http://127.0.0.1:8093/process/v1/tool-calls/'+name,json.dumps(args).encode(),{'Content-Type':'application/json','X-Correlation-ID':'stub-'+uuid.uuid4().hex,'Idempotency-Key':args.get('idempotencyKey','')})
        try:r=urlopen(req,timeout=10)
        except HTTPError as e:r=e
        with r:return r.status,json.load(r)

    def test_eight_endpoints(self):
        start=date.today()+timedelta(days=60+uuid.uuid4().int%10000)
        for p in sorted((ROOT/'src/main/resources/api/examples').glob('*.json')):
            if p.stem.endswith('Response'):continue
            with self.subTest(tool=p.stem):
                args=json.loads(p.read_text())
                if 'checkIn' in args:args.update(checkIn=start.isoformat(),checkOut=(start+timedelta(days=2)).isoformat())
                if p.stem=='createBooking':args.update(confirmed=True,idempotencyKey='stub-'+uuid.uuid4().hex)
                status,result=self.send(p.stem,args)
                self.assertEqual(status,201 if p.stem=='createBooking' else 200,result)
                self.assertTrue(result)
                if p.stem=='createBooking':
                    self.assertEqual(self.send(p.stem,args),(status,result))
                    args['adults']=1
                    self.assertEqual(self.send(p.stem,args)[0],409)

    def test_failures(self):
        for pid,status in [('MISSING',404),('TECH-503',503),('TECH-TIMEOUT',504)]:
            self.assertEqual(self.send('getPropertyDetails',{'propertyId':pid})[0],status)

if __name__=='__main__':unittest.main(verbosity=2)

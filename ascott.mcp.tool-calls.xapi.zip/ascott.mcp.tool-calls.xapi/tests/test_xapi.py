"""Live contract/routing tests: python tests/test_xapi.py (stack must be running)."""
import unittest,json,uuid
from urllib.request import Request,urlopen
from urllib.error import HTTPError
from pathlib import Path
from datetime import date,timedelta

BASE='http://127.0.0.1:8082/api/v1'
ROOT=Path(__file__).resolve().parents[1]

class ExperienceAPI(unittest.TestCase):
    def send(self,path,args=None,method='POST',mime='application/json',trace=None):
        trace=trace or 'test-'+uuid.uuid4().hex
        data=json.dumps(args).encode() if args is not None else None
        req=Request(BASE+path,data,{'Content-Type':mime,'Accept':'application/json','X-Correlation-ID':trace},method=method)
        try: response=urlopen(req,timeout=15)
        except HTTPError as exc: response=exc
        with response:
            return response.status,json.load(response),response.headers

    def test_all_eight_process_routes(self):
        files=ROOT/'src/main/resources/api/examples'
        start=date.today()+timedelta(days=60+uuid.uuid4().int%10000)
        calls=[]
        for path in sorted(files.glob('*.json')):
            if path.stem.endswith('Response'): continue
            args=json.loads(path.read_text())
            if 'checkIn' in args: args.update(checkIn=start.isoformat(),checkOut=(start+timedelta(days=2)).isoformat())
            if path.stem=='createBooking': args.update(confirmed=True,idempotencyKey='xapi-'+uuid.uuid4().hex)
            trace='route-'+uuid.uuid4().hex
            status,body,headers=self.send('/tool-calls/'+path.stem,args,trace=trace)
            self.assertEqual(status,201 if path.stem=='createBooking' else 200,(path.stem,body))
            self.assertEqual(headers.get('X-Correlation-ID'),trace)
            self.assertTrue(body)
            calls.append((path.stem,trace))
        # Verify the actual downstream requester was used for every route.
        records=[json.loads(line) for line in (ROOT/'logs/process-audit.jsonl').read_text().splitlines()]
        for name,trace in calls:
            self.assertTrue(any(r['tool']==name and r['correlationId']==trace for r in records),(name,trace))
        self.assertEqual(len(calls),8)

    def test_apikit_rejects_invalid_schema(self):
        for args in ({},{'propertyId':'../bad'},{'propertyId':'SG-001','extra':True}):
            status,body,_=self.send('/tool-calls/getPropertyDetails',args)
            self.assertEqual(status,400,body)
            self.assertEqual(body['error']['category'],'FUNCTIONAL')

    def test_apikit_unknown_resource(self):
        status,body,_=self.send('/tool-calls/unknown',{})
        self.assertEqual(status,404,body)

    def test_apikit_wrong_method(self):
        status,body,_=self.send('/tool-calls/getPropertyDetails',method='GET')
        self.assertEqual(status,405,body)

    def test_apikit_wrong_media_type(self):
        status,body,_=self.send('/tool-calls/getPropertyDetails',{'propertyId':'SG-001'},mime='text/plain')
        self.assertEqual(status,415,body)

    def test_downstream_functional_and_technical(self):
        for pid,status_expected,category in [('MISSING',404,'FUNCTIONAL'),('TECH-503',502,'TECHNICAL'),('TECH-TIMEOUT',504,'TECHNICAL')]:
            status,body,_=self.send('/tool-calls/getPropertyDetails',{'propertyId':pid})
            self.assertEqual(status,status_expected,body)
            self.assertEqual(body['error']['category'],category)
            self.assertTrue(body['correlationId'])

if __name__=='__main__': unittest.main(verbosity=2)
